import tkinter as tk

class Calculator:
    def __init__(self, root):
        root.title("Calculator")
        root.geometry("360x480")
        root.resizable(False, False)
        root.configure(bg="#1e1e1e")

        self.expression = ""

        self.display = tk.Entry(root, font=("Helvetica", 24), borderwidth=0, relief=tk.FLAT, justify='right', bg="#1e1e1e", fg="white")
        self.display.grid(row=0, column=0, columnspan=4, sticky="nsew", padx=10, pady=20)
        self.display.insert(0, "0")

        buttons = [
            ('C', 1, 0, '#ff5c5c'), ('←', 1, 1, '#ff9500'), ('%', 1, 2, '#ff9500'), ('/', 1, 3, '#ff9500'),
            ('7', 2, 0, '#2d2d2d'), ('8', 2, 1, '#2d2d2d'), ('9', 2, 2, '#2d2d2d'), ('*', 2, 3, '#ff9500'),
            ('4', 3, 0, '#2d2d2d'), ('5', 3, 1, '#2d2d2d'), ('6', 3, 2, '#2d2d2d'), ('-', 3, 3, '#ff9500'),
            ('1', 4, 0, '#2d2d2d'), ('2', 4, 1, '#2d2d2d'), ('3', 4, 2, '#2d2d2d'), ('+', 4, 3, '#ff9500'),
            ('+/-', 5, 0, '#2d2d2d'), ('0', 5, 1, '#2d2d2d'), ('.', 5, 2, '#2d2d2d'), ('=', 5, 3, '#ff9500'),
        ]

        for (text, row, col, color) in buttons:
            action = lambda x=text: self.on_click(x)
            b = tk.Button(root, text=text, bg=color, fg="white", font=("Helvetica", 20), borderwidth=0, command=action)
            b.grid(row=row, column=col, sticky="nsew", padx=5, pady=5)

        for i in range(6):
            root.grid_rowconfigure(i, weight=1)
        for i in range(4):
            root.grid_columnconfigure(i, weight=1)

    def on_click(self, char):
        if char == 'C':
            self.expression = ""
            self.display.delete(0, tk.END)
            self.display.insert(0, "0")
        elif char == '←':
            self.expression = self.expression[:-1]
            self.update_display()
        elif char == '=':
            self.calculate()
        elif char == '+/-':
            self.toggle_sign()
        else:
            if char in '+-*/%':
                if self.expression and self.expression[-1] in '+-*/%':
                    self.expression = self.expression[:-1] + char
                elif not self.expression:
                    if char == '-':  # allow negative start
                        self.expression += char
                else:
                    self.expression += char
            else:
                self.expression += char
            self.update_display()

    def update_display(self):
        self.display.delete(0, tk.END)
        self.display.insert(0, self.expression if self.expression else "0")

    def calculate(self):
        try:
            expr = self.expression.replace('%', '/100')
            result = eval(expr)
            self.expression = str(result)
            self.update_display()
        except Exception:
            self.display.delete(0, tk.END)
            self.display.insert(0, "Error")
            self.expression = ""

    def toggle_sign(self):
        if self.expression:
            if self.expression[0] == '-':
                self.expression = self.expression[1:]
            else:
                self.expression = '-' + self.expression
            self.update_display()

if __name__ == "__main__":
    root = tk.Tk()
    calc = Calculator(root)
    root.mainloop()
